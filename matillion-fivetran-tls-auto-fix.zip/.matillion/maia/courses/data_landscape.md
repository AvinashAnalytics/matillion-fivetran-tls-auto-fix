## opportunities
Records individual sales opportunities tracked through your pipeline, capturing the deal value, stage progression, sales representative ownership, and win outcomes.
Columns: opportunity_id, rep_id, stage_id, date, opportunity_value, win_flag, sales_cycle_days

## sales_rep
Provides reference information about your sales team members, including their geographic region, experience level, and individual sales quotas.
Columns: rep_id, rep_name, region, years_experience, quota_amount

## pipeline_stage
Defines the stages of your sales process, including the typical duration and historical conversion probability at each stage.
Columns: stage_id, stage_name, stage_sequence, expected_duration_days, conversion_probability

## Data Relationships
opportunities.rep_id → sales_rep.rep_id
opportunities.stage_id → pipeline_stage.stage_id

## Use Cases
As a data analyst, you can use the opportunities table joined with sales_rep and pipeline_stage to analyze sales performance metrics such as win rates by region, average sales cycle length by representative experience level, and forecast pipeline value based on stage-specific conversion probabilities. You can identify top-performing sales reps against their quotas, track deal progression velocity through stages, and uncover bottlenecks in your sales process by examining how opportunities move through the pipeline stages and which stages have the longest expected durations.